<?php
header('Content-Type: application/json');

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "Ayan12345";
$dbname = "periodic_table";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

// Get input from GET or POST (depending on your frontend)
$input = $_GET['input'] ?? '';

if (!$input) {
    echo json_encode(['error' => 'No input provided']);
    exit;
}

// Prepare SQL to fetch info by atomic number or symbol
$sql = $conn->prepare("
    SELECT e.atomic_number, e.symbol, e.name, ei.history, ei.presence, ei.market_value
    FROM elements e
    JOIN element_info ei ON e.atomic_number = ei.atomic_number
    WHERE e.atomic_number = ? OR e.symbol = ?
    LIMIT 1
");

// Determine if input is numeric (atomic number) or string (symbol)
if (is_numeric($input)) {
    $atomicNumber = intval($input);
    $symbol = '';
    $sql->bind_param("is", $atomicNumber, $symbol);
} else {
    $atomicNumber = 0;
    $symbol = strtoupper($input);
    $sql->bind_param("is", $atomicNumber, $symbol);
}

$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    echo json_encode($data);
} else {
    echo json_encode(['error' => 'Element not found']);
}

$conn->close();
?>
