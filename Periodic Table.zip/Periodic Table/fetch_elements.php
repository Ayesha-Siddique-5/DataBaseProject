<?php
header('Content-Type: application/json');
$conn = new mysqli('localhost', 'root', 'Ayan12345', 'periodic_table');
if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed']));
}

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'atomic_number':
        $atomic_number = intval($_POST['atomic_number'] ?? 0);
        $stmt = $conn->prepare("SELECT * FROM elements WHERE atomic_number = ?");
        $stmt->bind_param("i", $atomic_number);
        $stmt->execute();
        $result = $stmt->get_result();
        echo json_encode($result->fetch_assoc());
        break;

    case 'property_range':
        $property = $_POST['property'] ?? '';
        $min_val = floatval($_POST['min_val'] ?? 0);
        $max_val = floatval($_POST['max_val'] ?? 0);
        if (!in_array($property, ['ionization_energy', 'electronegativity', 'density', 'melting_point', 'boiling_point'])) {
            echo json_encode(['error' => 'Invalid property']);
            exit;
        }
        $stmt = $conn->prepare("SELECT * FROM elements WHERE $property BETWEEN ? AND ?");
        $stmt->bind_param("dd", $min_val, $max_val);
        $stmt->execute();
        $result = $stmt->get_result();
        $elements = [];
        while ($row = $result->fetch_assoc()) {
            $elements[] = $row;
        }
        echo json_encode($elements);
        break;

    case 'period':
        $period = intval($_POST['period'] ?? 0);
        $stmt = $conn->prepare("SELECT * FROM elements WHERE period = ?");
        $stmt->bind_param("i", $period);
        $stmt->execute();
        $result = $stmt->get_result();
        $elements = [];
        while ($row = $result->fetch_assoc()) {
            $elements[] = $row;
        }
        echo json_encode($elements);
        break;

    case 'group':
        $group = intval($_POST['group'] ?? 0);
        $stmt = $conn->prepare("SELECT * FROM elements WHERE group_number = ?");
        $stmt->bind_param("i", $group);
        $stmt->execute();
        $result = $stmt->get_result();
        $elements = [];
        while ($row = $result->fetch_assoc()) {
            $elements[] = $row;
        }
        echo json_encode($elements);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
        break;
}

$conn->close();
?>
