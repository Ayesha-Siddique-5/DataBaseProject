<?php
// DB credentials
$servername = "localhost";
$username = "root";
$password = "Ayan12345";
$dbname = "periodic_table";

// Connect
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch reviews
$sql = "SELECT feedback, changes, problems, submitted_at FROM reviews ORDER BY submitted_at DESC";
$result = $conn->query($sql);

// Display reviews
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='review-card'>";
        echo "<p><strong>Feedback:</strong> " . htmlspecialchars($row['feedback']) . "</p>";
        echo "<p><strong>Suggested Changes:</strong> " . htmlspecialchars($row['changes']) . "</p>";
        echo "<p><strong>Problems:</strong> " . htmlspecialchars($row['problems']) . "</p>";
        echo "<small><em>Submitted on: " . $row['submitted_at'] . "</em></small>";
        echo "</div><hr>";
    }
} else {
    echo "<p>No reviews submitted yet.</p>";
}

$conn->close();
?>
