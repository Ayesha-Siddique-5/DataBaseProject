<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "Ayan12345";
$dbname = "periodic_table";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get posted data safely
$feedback = $_POST['feedback'] ?? '';
$changes = $_POST['changes'] ?? '';
$problems = $_POST['problems'] ?? '';

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO reviews (feedback, changes, problems) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $feedback, $changes, $problems);

if ($stmt->execute()) {
    echo "Review submitted successfully.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
